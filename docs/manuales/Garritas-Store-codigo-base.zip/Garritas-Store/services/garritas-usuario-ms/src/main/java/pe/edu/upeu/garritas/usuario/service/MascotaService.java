package pe.edu.upeu.garritas.usuario.service;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pe.edu.upeu.garritas.usuario.dto.MascotaRequest;
import pe.edu.upeu.garritas.usuario.dto.MascotaResponse;
import pe.edu.upeu.garritas.usuario.entity.Mascota;
import pe.edu.upeu.garritas.usuario.exception.ResourceNotFoundException;
import pe.edu.upeu.garritas.usuario.mapper.MascotaMapper;
import pe.edu.upeu.garritas.usuario.repository.MascotaRepository;

@org.springframework.transaction.annotation.Transactional
@Service
@RequiredArgsConstructor
public class MascotaService {

  private final MascotaRepository mascotaRepository;
  private final MascotaMapper mascotaMapper;
  private final UsuarioService usuarioService;

  public List<MascotaResponse> listarPorUsuario(Long usuarioId) {
    usuarioService.buscarOFallar(usuarioId);
    return mascotaRepository.findByUsuarioId(usuarioId).stream()
        .map(mascotaMapper::toResponse)
        .toList();
  }

  public MascotaResponse crear(Long usuarioId, MascotaRequest request) {
    Mascota mascota = mascotaMapper.toEntity(request);
    mascota.setUsuario(usuarioService.buscarOFallar(usuarioId));
    return mascotaMapper.toResponse(mascotaRepository.save(mascota));
  }

  public MascotaResponse actualizar(Long id, MascotaRequest request) {
    Mascota mascota = buscarOFallar(id);
    mascota.setNombre(request.getNombre());
    mascota.setEspecie(request.getEspecie());
    mascota.setRaza(request.getRaza());
    mascota.setEdad(request.getEdad());
    return mascotaMapper.toResponse(mascotaRepository.save(mascota));
  }

  public void eliminar(Long id) {
    mascotaRepository.delete(buscarOFallar(id));
  }

  public MascotaResponse obtener(Long id) {
    return mascotaMapper.toResponse(buscarOFallar(id));
  }

  public void verificarUsuario(Long usuarioId, Long mascotaId) {
    Mascota mascota = buscarOFallar(mascotaId);
    if (!mascota.getUsuario().getId().equals(usuarioId))
      throw new org.springframework.web.server.ResponseStatusException(
          org.springframework.http.HttpStatus.NOT_FOUND,
          "La mascota no pertenece al perfil indicado");
  }

  private Mascota buscarOFallar(Long id) {
    Mascota mascota =
        mascotaRepository
            .findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Mascota no encontrada: " + id));
    pe.edu.upeu.garritas.common.CurrentUser.requireOwner(mascota.getUsuario().getSubject());
    return mascota;
  }
}
