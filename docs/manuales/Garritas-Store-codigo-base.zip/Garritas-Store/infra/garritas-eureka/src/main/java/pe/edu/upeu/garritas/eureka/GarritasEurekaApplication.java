package pe.edu.upeu.garritas.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class GarritasEurekaApplication {
    public static void main(String[] args) {
        SpringApplication.run(GarritasEurekaApplication.class, args);
    }
}